import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o nome da pessoa: ");
        String nome = scanner.nextLine();

        System.out.print("Digite o número da conta: ");
        String numeroConta = scanner.nextLine();

        System.out.print("Digite o saldo inicial: ");
        double saldoInicial = scanner.nextDouble();

        ContaBancaria conta = new ContaBancaria(nome, numeroConta, saldoInicial);

        System.out.println("Conta bancária criada com sucesso.");

        String opcao;

        do {
            System.out.println("\nEscolha uma opção:");
            System.out.println("1 Depositar");
            System.out.println("2 Sacar");
            System.out.println("3 Ver saldo");
            System.out.println("Q Sair");
            System.out.print("Opção: ");
            opcao = scanner.next();

            if (opcao.equals("1")) {
                System.out.print("Digite o valor para depósito: ");
                double valor = scanner.nextDouble();
                conta.depositar(valor);

            } else if (opcao.equals("2")) {
                System.out.print("Digite o valor para saque: ");
                double valor = scanner.nextDouble();
                conta.sacar(valor);

            } else if (opcao.equals("3")) {
                conta.mostrarSaldo();

            } else if (!opcao.equalsIgnoreCase("Q")) {
                System.out.println("Opção inválida.");
            }

        } while (!opcao.equalsIgnoreCase("Q"));

        System.out.println("Programa encerrado.");
    }
}
